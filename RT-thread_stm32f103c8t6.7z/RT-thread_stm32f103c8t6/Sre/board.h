#ifndef __BOARD_H__
#define __BOARD_H__
/**************************************************************************
  ������ͷ�ļ�
***************************************************************************/
/* STM32 �̼���ͷ�ļ� */
#include "stm32f10x.h"
#include "rtconfig.h"
#if defined(RT_USING_USER_MAIN) && defined(RT_USING_HEAP)

#define STM32_SRAM_SIZE 20
#define STM32_SRAM_END (0x20000000 + STM32_SRAM_SIZE * 1024)
#ifdef __CC_ARM
extern int Image$$RW_IRAM1$$ZI$$Limit;
#define HEAP_BEGIN  ((void *)&Image$$RW_IRAM1$$ZI$$Limit)
#elif __ICCARM__
#pragma section="HEAP"
#define HEAP_BEGIN  (__segment_end("HEAP"))
#else
extern int __bss_end;
#define HEAP_BEGIN  ((void *)&__bss_end)
#endif
#define HEAP_END    STM32_SRAM_END

#endif
/* ������Ӳ�� bsp ͷ�ļ� */
/***************************************************************************
��������
***************************************************************************/
void rt_hw_board_init(void);
void SysTick_Handler(void);
#endif

