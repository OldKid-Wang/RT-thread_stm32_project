#ifndef __LED_H
#define __LED_H
#include "stm32f10x.h"
#define OFF 0
#define ON  1
int LED_Init(void);
void LED_Control(u16 pin,u8 stutas);
#endif

