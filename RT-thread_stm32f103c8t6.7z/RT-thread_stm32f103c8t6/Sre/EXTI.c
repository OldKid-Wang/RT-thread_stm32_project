#include "EXTI.h"
#include "LED.h"

rt_sem_t EXTI_sem = RT_NULL;

int EXTI_config()
{
	GPIO_InitTypeDef GPIO_InitStucture;
	NVIC_InitTypeDef NVIC_InitStucture;
	EXTI_InitTypeDef EXTI_InitStucture;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_InitStucture.GPIO_Pin=GPIO_Pin_5;
	GPIO_InitStucture.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStucture.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStucture);
	
	NVIC_InitStucture.NVIC_IRQChannel=EXTI9_5_IRQn;
	NVIC_InitStucture.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStucture.NVIC_IRQChannelSubPriority=1;
	NVIC_InitStucture.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStucture);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource5);
	
	EXTI_InitStucture.EXTI_Line=EXTI_Line5;
	EXTI_InitStucture.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStucture.EXTI_Trigger=EXTI_Trigger_Falling;
	EXTI_InitStucture.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStucture);
    
    EXTI_sem = rt_sem_create("Pulse_sem", 0, RT_IPC_FLAG_FIFO);
    return 0;
    
}
INIT_PREV_EXPORT(EXTI_config);



void EXTI9_5_IRQHandler(void)
{
    
    rt_interrupt_enter();
   	if((EXTI_GetITStatus(EXTI_Line5)!=RESET))
	{
        rt_sem_release(EXTI_sem);       
        EXTI_ClearITPendingBit(EXTI_Line5);       
	}
    rt_interrupt_leave();
}


