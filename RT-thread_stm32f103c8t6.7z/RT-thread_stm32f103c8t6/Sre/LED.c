#include "LED.h"
#include "ADC.h"
static int AD_value=0;
extern u8 taillight_flag;
extern u8 illumination_flag;

extern u8 LOW_power_flag;

int LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
  
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	return 0;	
}
INIT_BOARD_EXPORT(LED_Init);

void LED_Control(u16 pin,u8 stutas)
{
	
	if(stutas==1)
	{		
		GPIO_SetBits(GPIOC,pin);
    }
	else
	{
		GPIO_ResetBits(GPIOC,pin);
	}
}


static void LED_entry(void* parameter)
{
    while(1)
    {
        AD_value=(int)(ADC_Getvalue()*100);
        LED_Control(GPIO_Pin_13,OFF);
        rt_thread_delay(500);
        LED_Control(GPIO_Pin_13, ON);
        rt_thread_delay(500);       
       
        if((taillight_flag==0x31)||(AD_value>100))
        {
            LED_Control(GPIO_Pin_14, OFF);
            rt_thread_mdelay(200);
            LED_Control(GPIO_Pin_14, ON);
            rt_thread_mdelay(200);
        }            
        else LED_Control(GPIO_Pin_14, ON);
        if((illumination_flag==0x31)||(AD_value>100)) LED_Control(GPIO_Pin_15, ON);
        else LED_Control(GPIO_Pin_15, OFF);

    }
    
}

static rt_thread_t LED_thread=RT_NULL;

int Creat_LED_thread(void)
{
    LED_thread=rt_thread_create("LED",
                                LED_entry,
                                RT_NULL,
                                512,9,5);
    if(LED_thread!=RT_NULL)
    rt_thread_startup(LED_thread);
    return 0;

}
INIT_PREV_EXPORT(Creat_LED_thread);
