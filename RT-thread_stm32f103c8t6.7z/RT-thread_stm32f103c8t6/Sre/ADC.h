#ifndef __ADC_H
#define __ADC_H
#include "stm32f10x.h"
#include "stm32f10x_adc.h"
int ADC_Config(void);
float ADC_Getvalue(void);
#endif
