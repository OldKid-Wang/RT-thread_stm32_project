#include "USART.h"
#include "AT24C02.h"
int USART1_config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	
	USART_InitStructure.USART_BaudRate=115200;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1,&USART_InitStructure);
	
	USART_Cmd(USART1,ENABLE);
    return 0;
}
INIT_BOARD_EXPORT(USART1_config);



int USART2_config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStructure.NVIC_IRQChannel=USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_InitStructure.USART_BaudRate=9600;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b;
	USART_InitStructure.USART_StopBits=USART_StopBits_1;
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2,&USART_InitStructure);
	
	USART_Cmd(USART2,ENABLE);
	USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
    return 0;

}
INIT_BOARD_EXPORT(USART2_config);

/*D_mailbox ����r_communication��Pdown_protectionͨ�� ���泵��ֱ��*/
rt_mailbox_t D_mailbox = RT_NULL;

static int D_mb_creadte(void)
{
    D_mailbox = rt_mb_create("D_mailbox",10,RT_IPC_FLAG_FIFO);
    if (D_mailbox != RT_NULL)
    {
        rt_kprintf("create D_mailbox successful.\n");
        return -1;
    }
    else 
    {
        rt_kprintf("create D_mailbox failed.\n");
        return 0;     
    } 
}

INIT_PREV_EXPORT(D_mb_creadte);


/*N_mailbox ����r_communication��Pdown_protectionͨ�� ����Ÿָ���*/
rt_mailbox_t N_mailbox = RT_NULL;

static int N_mb_creadte(void)
{
    N_mailbox = rt_mb_create("N_mailbox",10,RT_IPC_FLAG_FIFO);
    if (N_mailbox != RT_NULL)
    {
        rt_kprintf("create N_mailbox successful.\n");
        return -1;
    }
    else 
    {
        rt_kprintf("create N_mailbox failed.\n");
        return 0;     
    } 
}

INIT_PREV_EXPORT(N_mb_creadte);


u8 RX_string[20];
static u8 RX_OverFlag;
u8 counter=0;
void USART2_IRQHandler(void)
{
    
    
	if(USART_GetITStatus(USART2,USART_IT_RXNE)!=RESET)
	{
		USART_ClearITPendingBit(USART2,USART_IT_RXNE); 
        RX_string[counter]=USART_ReceiveData(USART2); 
        if(RX_string[counter]==111)
			{
				USART_ITConfig(USART2,USART_IT_RXNE,DISABLE);
                RX_OverFlag=1;				
				
			}
		else
			{
				counter++;
			}
	}
}


/*�������ͨ���߳�*/
static rt_thread_t r_communication_thread = RT_NULL;
u8 taillight_flag=0;
u8 illumination_flag=0;
u16 receive_D=660;
u8 receive_number=1;
u8 inf_flag=0;

static void r_communication_thread_entry(void* parameter)
{
    while(1)
	{
        if(RX_OverFlag==1)				//������Ϣ����
			{
                
                if(RX_string[0]==0x31)
                {
                    taillight_flag=RX_string[1];
                } 
                else if(RX_string[0]==0x32)
                {
                    illumination_flag=RX_string[1];
                }
                else if(RX_string[0]==0x33)
                {
                    receive_D=(RX_string[1]-0x30)*100+(RX_string[2]-0x30)*10+(RX_string[3]-0x30);
                    receive_number=RX_string[4]-0x30;  
                    rt_mb_send(D_mailbox,receive_D); 
                    rt_mb_send(N_mailbox,receive_number); 
                    inf_flag=1;                       

                }
                RX_OverFlag=0;
				USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);  
                counter=0;
			}

        rt_thread_mdelay(2);
        
	}
}

int Create_r_communication(void)
{
    r_communication_thread=rt_thread_create("r_communication",
                                r_communication_thread_entry,
                                RT_NULL,
                                256,8,5);
    if(r_communication_thread!=RT_NULL)
    rt_thread_startup(r_communication_thread);
    return 0;
}

INIT_PREV_EXPORT(Create_r_communication);

extern rt_mailbox_t S_mailbox;
extern rt_mailbox_t M_mailbox;

static rt_thread_t s_communication_thread = RT_NULL;



static void s_communication_thread_entry(void* parameter)
{
    u32 number=0;
    u16 S_value=0;
    static u32 M_value=0;
    static u32 Mileage=0;
    static u8 flag=1;
    static u32 Mileage_out;
    u8 hundreds_of_digit=0;
    u8 all_digit=0;
    u8 thousands_digit=0;
    u8 handreds_digit=0;
    u8 tens_digit=0;
    u8 units_digit=0;
    
    while(1)
	{
       if(rt_mb_recv(S_mailbox, (rt_uint32_t *)&S_value, RT_WAITING_NO)==RT_EOK)
       {
                  
           thousands_digit=S_value/1000;
           handreds_digit=S_value%1000/100;
           tens_digit=S_value%100/10;
           units_digit=S_value%10;
           USART_SendData(USART2,'S');
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+thousands_digit);
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+handreds_digit);
           rt_thread_mdelay(2);
           USART_SendData(USART2,'.'); 
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+tens_digit);
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+units_digit);
           rt_thread_mdelay(2);            
       }
       if(rt_mb_recv(M_mailbox, (rt_uint32_t *)&M_value, RT_WAITING_NO)==RT_EOK)
       {
           number=AT24CXX_ReadLenByte(0x04,2);
           Mileage=(int)(M_value*3.14*number)/10000;
           if(flag==1){Mileage_out=(int)(M_value*3.14*number)/10000;flag=0;}
           if(((Mileage>=Mileage_out)&&(Mileage<=Mileage_out+10)))
           Mileage_out=Mileage;
           rt_kprintf("Mileage is %d\n",Mileage_out);
           hundreds_of_digit=Mileage_out/100000;
           all_digit=Mileage_out%100000/10000;
           thousands_digit=Mileage_out%10000/1000;
           handreds_digit=Mileage_out%1000/100;
           tens_digit=Mileage_out%100/10;
           units_digit=Mileage_out%10; 
           USART_SendData(USART2,'M');
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+hundreds_of_digit);
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+all_digit); 
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+thousands_digit);
           rt_thread_mdelay(2);
           USART_SendData(USART2,0x30+handreds_digit);
           rt_thread_mdelay(2);
           USART_SendData(USART2,'.');
           rt_thread_mdelay(2);            
           USART_SendData(USART2,0x30+tens_digit);
           rt_thread_mdelay(2); 
           USART_SendData(USART2,0x30+units_digit);
           rt_thread_mdelay(2);
           USART_SendData(USART2,' ');
           rt_thread_mdelay(5);

       }
        rt_thread_mdelay(20);
                
	}
}

int Create_s_communication(void)
{
    s_communication_thread=rt_thread_create("s_communication",
                                s_communication_thread_entry,
                                RT_NULL,
                                512,8,5);
    if(s_communication_thread!=RT_NULL)
    rt_thread_startup(s_communication_thread);
    return 0;
}

INIT_PREV_EXPORT(Create_s_communication);
