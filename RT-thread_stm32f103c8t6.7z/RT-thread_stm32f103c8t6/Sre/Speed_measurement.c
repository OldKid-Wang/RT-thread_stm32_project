#include <rtthread.h>
#include "AT24C02.h"
#include "LED.h"
/*M_mailbox ����Speed_measurement��Pdown_protectionͨ�� ����������*/
rt_mailbox_t M_mailbox = RT_NULL;

static int M_mb_creadte(void)
{
    M_mailbox = rt_mb_create("M_mailbox",10,RT_IPC_FLAG_FIFO);
    if (M_mailbox != RT_NULL)
    {
        rt_kprintf("create mailbox successful.\n");
        return -1;
    }
    else 
    {
        rt_kprintf("create mailbox failed.\n");
        return 0;     
    } 
}
INIT_PREV_EXPORT(M_mb_creadte);
/*S_mailbox ����Speed_measurement��s_communicationͨ�� �ϴ��ٶ�ֵ*/
rt_mailbox_t S_mailbox = RT_NULL;

static int S_mb_creadte(void)
{
    S_mailbox = rt_mb_create("S_mailbox",10,RT_IPC_FLAG_FIFO);
    if (S_mailbox != RT_NULL)
    {
        rt_kprintf("create S_mailbox successful.\n");
        return -1;
    }
    else 
    {
        rt_kprintf("create S_mailbox failed.\n");
        return 0;     
    } 
}
INIT_PREV_EXPORT(S_mb_creadte);


static rt_thread_t S_measurement = RT_NULL;

static float speed=0;
static int out_speed=0;
u16 D=660;
u8 magnet_number=1;



extern rt_sem_t EXTI_sem ;         
extern int Periodic_Pulse_time;
static u32 Pulse_cnt=0;
static rt_err_t Pulse_result; 
static int Pulse_time=0;

extern u32 LOW_POWER_time;
extern u8 inf_flag;

void speed_measurement_entry(void* parameter)
{
    static char number=1;

    Pulse_cnt=AT24CXX_ReadLenByte(0x00,4);
    

    while(1)
    {
        
        Pulse_result =  rt_sem_trytake(EXTI_sem);
        if (Pulse_result == RT_EOK)
        {
            
            if(number == 1)
            {
                Periodic_Pulse_time = 0;
                number = 2;
            }
            else if(number == 2)
            {
                Pulse_time = Periodic_Pulse_time;               
                number = 1;
            }
            D=AT24CXX_ReadLenByte(0x04,2);
            magnet_number=AT24CXX_ReadLenByte(0x06,1);
            rt_enter_critical();
            speed=3.14*D/magnet_number/Pulse_time;
            out_speed=speed*100;
            rt_mb_send(S_mailbox,out_speed);
            rt_exit_critical();
            Pulse_cnt+=1;             
            rt_mb_send(M_mailbox,Pulse_cnt);
            rt_mb_send(M_mailbox,Pulse_cnt);
            LOW_POWER_time=0;                                           
        }
        rt_thread_mdelay(1);
    }
      
            
}


static int S_measurement_creadte(void)
{
    S_measurement=rt_thread_create("speed_measurement",
                                speed_measurement_entry,
                                RT_NULL,
                                512,9,5);
    if(S_measurement!=RT_NULL)
    rt_thread_startup(S_measurement);
    return 0;
}
INIT_APP_EXPORT(S_measurement_creadte); 



