/*
 * Copyright (c) 2006-2019, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2017-07-24     Tanek        the first version
 * 2018-11-12     Ernest Chen  modify copyright
 */
#include <board.h> 
#include <rthw.h>
#include <rtthread.h>
#include "USART.h"
#include "LED.h"

void rt_hw_board_init()
{
    /* System Clock Update */
    
    /* System Tick Configuration */
    SysTick_Config( SystemCoreClock / RT_TICK_PER_SECOND );
    
    /* Ӳ��BSP��ʼ��ͳͳ�����������LED�����ڣ�LCD��*/

    /* ���������ʼ������ (use INIT_BOARD_EXPORT()) */
#ifdef RT_USING_COMPONENTS_INIT
    rt_components_board_init();
#endif

#if defined(RT_USING_USER_MAIN) && defined(RT_USING_HEAP)
    //rt_system_heap_init(rt_heap_begin_get(), rt_heap_end_get());
    rt_system_heap_init((void *)HEAP_BEGIN, (void *)HEAP_END);
#endif
}

void rt_hw_console_output(const char *str)
{
    /* empty console output */
    rt_enter_critical();/* ֱ���ַ������� */

    while (*str!='\0')
    {
        /* ���� */
        if (*str=='\n')
        {
         USART_SendData(USART1, '\r');
         while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
        }
         
        USART_SendData(USART1, *str++);
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    }
     
    rt_exit_critical();/* �˳��ٽ�� */       
}


char rt_hw_console_getchar(void)
{
    int ch = -1;

    if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != RESET)
    {
        ch = USART1->DR & 0xff;
    }
    else
    {
        if(USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET)
        {
            USART_ClearFlag(USART1,USART_FLAG_ORE);
        }
        rt_thread_mdelay(10);
    }
    return ch;
}

extern u8 LOW_power_flag;
extern u32 LOW_POWER_time;

void SysTick_Handler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    rt_tick_increase();
    /* leave interrupt */
    if(LOW_power_flag==1)
    {
        rt_kprintf("The controller goes into sleep mode\n");
         LED_Control(GPIO_Pin_13,ON);
        __WFI(); 
        LOW_power_flag=0;
        LOW_POWER_time=0;
    } 
    rt_interrupt_leave();
}
