#ifndef __EXTI_H
#define __EXTI_H
#include "stm32f10x.h"
#include "misc.h"
#include "stm32f10x_exti.h"
int EXTI_config(void);
#endif

