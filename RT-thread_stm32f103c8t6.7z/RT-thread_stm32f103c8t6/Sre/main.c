#include <rtthread.h>
#include "LED.h"

void Creat_LED_thread(void);

int main(void)
{
  return 0;
}


