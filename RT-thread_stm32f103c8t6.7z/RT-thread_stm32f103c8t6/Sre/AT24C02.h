#ifndef __AT24C02_H
#define __AT24C02_H
#include "i2c.h"

void AT24_write(int add,int data);
int AT24_read(int add);
void AT24CXX_WriteOneByte(u16 WriteAddr,u8 DataToWrite);
u8 AT24CXX_ReadOneByte(u16 ReadAddr);
void AT24CXX_WriteLenByte(u16 WriteAddr,u32 DataToWrite,u8 Len);
u32 AT24CXX_ReadLenByte(u16 ReadAddr,u8 Len);
#endif

