#ifndef __USART_H
#define __USART_H
#include "stm32f10x.h"
#include "stm32f10x_usart.h"
#include "misc.h"
int USART1_config(void);
int USART2_config(void);
void USART_sendstr(u8 *str);
#endif
