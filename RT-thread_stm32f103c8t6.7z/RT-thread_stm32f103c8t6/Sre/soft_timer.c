#include <rtthread.h>
#include "LED.h"

static rt_timer_t Pulse_timer;
static rt_timer_t LOW_power_timer;
u8 LOW_power_flag=0;
u32 Periodic_Pulse_time=0;
u32 LOW_POWER_time=0;

static void Pulse_timeout(void *parameter)
{    
    Periodic_Pulse_time++;
}

static int create_Pulse_timer(void)
{
    Pulse_timer = rt_timer_create("Pulse_timer", Pulse_timeout,
                             RT_NULL, 1,
                             RT_TIMER_FLAG_PERIODIC);
    if (Pulse_timer != RT_NULL) rt_timer_start(Pulse_timer);
    return 0;
}

INIT_APP_EXPORT(create_Pulse_timer);



static void LPOWER_timeout(void *parameter)
{    
    LOW_POWER_time++; 
//    rt_kprintf("LOW_POWER_time:%d\n",LOW_POWER_time);
       
}

static int create_LPOWER_timer(void)
{
    LOW_power_timer = rt_timer_create("LPOWER_timer", LPOWER_timeout,
                             RT_NULL, 1000,
                             RT_TIMER_FLAG_PERIODIC);
    if (LOW_power_timer != RT_NULL) rt_timer_start(LOW_power_timer);
    return 0;
}

INIT_APP_EXPORT(create_LPOWER_timer);    


static rt_thread_t Power_management_thread = RT_NULL;

static void Power_management_thread_entry(void* parameter)
{
    while(1)
    {
        if(LOW_POWER_time>=9) LOW_power_flag=1;
        rt_thread_mdelay(500);    
    }
}

int Create_Power_management(void)
{
    Power_management_thread=rt_thread_create("Power_management",
                                Power_management_thread_entry,
                                RT_NULL,
                                256,8,5);
    if(Power_management_thread!=RT_NULL)
    rt_thread_startup(Power_management_thread);
    return 0;
}
INIT_APP_EXPORT(Create_Power_management); 
